#!/bin/bash
set -ev
mvn clean package
