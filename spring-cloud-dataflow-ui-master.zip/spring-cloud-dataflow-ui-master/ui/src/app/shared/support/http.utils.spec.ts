xdescribe('HTTP Utils', () => {

  // it('Encode + in key', () => {
  //   expect(URL_QUERY_ENCODER.encodeKey('2 + 2 = 4')).toEqual('2%20%2B%202%20=%204');
  // });

  // it('Encode + in value', () => {
  //   expect(URL_QUERY_ENCODER.encodeValue('2 + 2 = 4')).toEqual('2%20%2B%202%20=%204');
  // });

});
