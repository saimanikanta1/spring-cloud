export interface KvRichTextValidators {

  key: Array<Function>;

  value: Array<Function>;

}
