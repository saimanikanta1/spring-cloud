export class PageRequest {
  constructor(public page: number, public size: number) {}
}
