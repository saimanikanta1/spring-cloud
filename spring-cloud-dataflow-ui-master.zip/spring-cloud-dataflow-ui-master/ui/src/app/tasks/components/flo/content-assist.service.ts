import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HttpUtils } from '../../../shared/support/http.utils';
import { map } from 'rxjs/operators';

@Injectable()
export class ContentAssistService {

  constructor(private httpClient: HttpClient) {
  }

  getProposals(prefix: string): Observable<Array<string>> {
    const httpHeaders = HttpUtils.getDefaultHttpHeaders();
    const params = new HttpParams()
      .append('start', prefix)
      .append('defaultLevel', '1');
    return this.httpClient.get<any>('/completions/task', {
      headers: httpHeaders,
      params: params
    }).pipe(map(jsonResponse => {
      return jsonResponse.proposals;
    }));
  }

}
