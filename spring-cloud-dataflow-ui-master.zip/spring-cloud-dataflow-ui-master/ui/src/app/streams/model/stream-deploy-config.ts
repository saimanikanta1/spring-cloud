/**
 * Represents a Stream Deploy Config.
 *
 * @author Damien Vitrac
 */
export class StreamDeployConfig {

  id: string;

  platform: any;

  deployers: any;

  apps: any;

  constructor() {

  }

}
