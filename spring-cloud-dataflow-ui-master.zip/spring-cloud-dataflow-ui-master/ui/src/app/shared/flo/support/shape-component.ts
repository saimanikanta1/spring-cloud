import { dia } from 'jointjs';

export class ShapeComponent {

  public data: any;

}

export class ElementComponent {

  public view: dia.ElementView;

}
