import { Component } from '@angular/core';

/**
 * Application Head Subtitle
 */
@Component({
  selector: 'app-page-head-subtitle',
  template: `<ng-content></ng-content>`
})
export class PageHeadSubtitleComponent {
}
